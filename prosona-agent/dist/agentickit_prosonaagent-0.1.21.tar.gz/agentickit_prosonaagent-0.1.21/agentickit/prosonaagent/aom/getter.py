from typing import Optional

from agentickit.prosonaagent.aom.state import AOMStateT
from agentickit.prosonaagent.aom.types import ActivityExtendSchema, SCOExtendSchema


def get_activity_by_activity_id(
    state: AOMStateT, activity_id: str
) -> Optional[ActivityExtendSchema]:
    activity_list = state.get("activity_list", [])
    for activity in activity_list:
        if activity.get("id") == activity_id:
            return activity


def get_next_activity_by_activity_id(
    state: AOMStateT, activity_id: str
) -> Optional[ActivityExtendSchema]:
    activity_list = state.get("activity_list", [])
    for index, activity in enumerate(activity_list):
        if activity.get("id") == activity_id and index != len(activity_list) - 1:
            return activity_list[index + 1]


def get_sco_by_sco_id(state: AOMStateT, sco_id: str) -> Optional[SCOExtendSchema]:
    activity_list = state.get("activity_list", [])
    for activity in activity_list:
        sco_list = state.get("activity_sco_list", {}).get(activity.get("id"), [])
        for sco in sco_list:
            if sco.get("id") == sco_id:
                return sco


def get_next_sco_by_sco_id(state: AOMStateT, sco_id: str) -> Optional[SCOExtendSchema]:
    activity_list = state.get("activity_list", [])
    for activity in activity_list:
        sco_list = state.get("activity_sco_list", {}).get(activity.get("id"), [])
        for index, sco in enumerate(sco_list):
            if sco.get("id") == sco_id:
                if index != len(sco_list) - 1:
                    return sco_list[index + 1]
