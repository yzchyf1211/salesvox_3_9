from typing import Any, Generic, Optional, cast, List

from agentickit.core.infra.skills.manager import get_skills_by_names
from langchain_core.messages import SystemMessage
from langgraph.runtime import Runtime
from typing_extensions import override

from agentickit.prosonaagent.aom.context import get_prompt_client
from agentickit.prosonaagent.aom.api import (
    get_project_info,
    get_project_modules,
    get_project_activities,
    get_sco_info,
)
from agentickit.prosonaagent.aom.context import (
    get_project_context,
    get_activity_context,
)
from agentickit.prosonaagent.aom.state import AOMSessionState, AOMStateT

# from agentickit.prosonaagent.aom.tools import get_activity_information
from agentickit.prosonaagent.context.common import build_skill_information_context_list
from agentickit.prosonaagent.middleware.session import SessionHandler
from agentickit.prosonaagent.utils.agent_proxy import UserAgentProxy
from agentickit.prosonaagent.utils.user import get_user_profile
from agentickit.prosonaagent.utils.time import get_timestamp
from .getter import (
    get_sco_by_sco_id,
    get_next_sco_by_sco_id,
    get_next_activity_by_activity_id,
)


class AOMSessionHandler(SessionHandler[AOMStateT], Generic[AOMStateT]):
    skills: List[str] = SessionHandler.skills
    state_schema: type[AOMStateT] = cast("type[AOMStateT]", AOMSessionState)
    tools = SessionHandler.tools

    @override
    async def aafter_user_input(
        self,
        state: AOMStateT,
        runtime: Runtime,
        user_input: str,
        action: Optional[str],
        params: Optional[dict[str, Any]],
    ) -> dict[str, Any] | None:
        if action == "biz-common-sco-restart":
            client = get_prompt_client(prompt_name="commands/restart")
            messages = [
                SystemMessage(
                    content=client.compile(
                        timestamp=get_timestamp(), activity_id=params.get("activity_id")
                    )
                ),
            ]

            return {
                "messages": messages,
            }

    @override
    async def abefore_session(
        self, state: AOMStateT, runtime: Runtime
    ) -> dict[str, Any] | None:
        updated = {}
        context_id = state.get("context_id")
        project_id = state.get("project_id", None)
        user_profile = get_user_profile(context_id)

        user_proxy = UserAgentProxy(state)
        params = user_proxy.get_params()
        project_id = params.get("projectId")
        updated["project_id"] = project_id

        project_info = await get_project_info(context_id, project_id)
        updated["project_info"] = project_info

        module_list = await get_project_modules(context_id, project_id)
        updated["module_list"] = module_list

        activity_list = await get_project_activities(context_id, project_id)
        updated["activity_list"] = activity_list

        # 预加载第一个小节
        activity = activity_list[0]
        sco_list = await get_sco_info(context_id, activity, user_profile)
        activity_sco_list = {activity.get("id"): sco_list}
        updated["activity_sco_list"] = activity_sco_list

        # 插入项目信息、第一个小节信息、manage_task技能信息，给Session Scope使用
        project_context = get_project_context(project_info)
        activity_context = get_activity_context(activity, sco_list)
        skills = get_skills_by_names(self.skills)
        skill_context = build_skill_information_context_list(skills)
        updated["messages"] = updated.get("messages", []) + [
            SystemMessage(content=project_context),
            SystemMessage(content=activity_context),
            SystemMessage(content=skill_context),
        ]

        return updated

    @override
    async def aafter_task(
        self,
        state: AOMStateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
        is_interrupt: bool,
    ) -> dict[str, Any] | None:
        updated = {}
        context_id = state.get("context_id")
        user_profile = get_user_profile(context_id)

        # 如果是最后一个SCO结束，则预热下一个小节
        current_sco = get_sco_by_sco_id(state, task_id)
        if current_sco:
            next_sco = get_next_sco_by_sco_id(state, current_sco.get("id"))
            if not next_sco:
                activity_id = current_sco.get("activity_id")
                next_activity = get_next_activity_by_activity_id(state, activity_id)
                if next_activity:
                    sco_list = await get_sco_info(
                        context_id, next_activity, user_profile
                    )
                    activity_sco_list = state.get("activity_sco_list", {})
                    activity_sco_list[next_activity.get("id")] = sco_list
                    updated["activity_sco_list"] = activity_sco_list

                    # 插入项目信息、下一个小节信息，给Session Scope使用
                    project_info = state.get("project_info", None)
                    project_context = get_project_context(project_info)
                    activity_context = get_activity_context(next_activity, sco_list)
                    skills = get_skills_by_names(self.skills)
                    skill_context = build_skill_information_context_list(skills)
                    updated["messages"] = updated.get("messages", []) + [
                        SystemMessage(content=project_context),
                        SystemMessage(content=activity_context),
                        SystemMessage(content=skill_context),
                    ]
                else:
                    # 最后一个activity，结束
                    updated["ended"] = True

        return updated
