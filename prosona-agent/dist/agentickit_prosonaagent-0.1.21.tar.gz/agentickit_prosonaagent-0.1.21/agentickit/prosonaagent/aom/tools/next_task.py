from langchain_core.tools import tool

from langgraph.prebuilt import ToolRuntime
from langgraph.types import Command

from langchain_core.messages import ToolMessage
from agentickit.prosonaagent.context.common import (
    build_tool_call_success_system_feedback,
    build_tool_call_error_system_feedback,
)
from ..getter import get_sco_by_sco_id, get_next_sco_by_sco_id


@tool
async def next_task(
    tool_runtime: ToolRuntime,
) -> Command:
    """
    run next sco of the current activity
    """
    current_sco = get_sco_by_sco_id(
        tool_runtime.state, tool_runtime.state.get("current_task_id")
    )
    if not current_sco:
        return Command(
            update={
                "messages": [
                    ToolMessage(
                        tool_call_id=tool_runtime.tool_call_id,
                        content=build_tool_call_error_system_feedback(
                            "can not call next_task when the current sco is not found, please call _builtin_start_task at first"
                        ),
                    )
                ]
            }
        )

    next_sco = get_next_sco_by_sco_id(tool_runtime.state, current_sco.get("id"))
    if not next_sco:
        return Command(
            update={
                "messages": [
                    ToolMessage(
                        tool_call_id=tool_runtime.tool_call_id,
                        content=build_tool_call_error_system_feedback(
                            "can not call next_task when the current sco is the last one, please call _builtin_end_task instead"
                        ),
                    )
                ]
            }
        )

    return Command(
        update={
            "messages": [
                ToolMessage(
                    tool_call_id=tool_runtime.tool_call_id,
                    content=build_tool_call_success_system_feedback(),
                )
            ]
        }
    )
