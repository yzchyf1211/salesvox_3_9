from langchain_core.tools import tool
from typing import Optional, Any

from langgraph.prebuilt import ToolRuntime
from langgraph.types import Command

from langchain_core.messages import ToolMessage
from agentickit.prosonaagent.context.common import (
    build_tool_call_success_system_feedback,
)


@tool
async def send_user_content(
    action: str,
    params: Optional[dict[str, Any]] = None,
    tool_runtime: ToolRuntime = None,
) -> Command:
    """
    Send content to user. Different tasks correspond to different content.
    Call the tool send_user_content to display the content, after which the user can view it on the interface.
    The detailed content is extensive and is mapped through defined actions.
    For details, refer to the action definitions within the task.

    Args:
        action: the action of the content, required
        params: the params of the content, optional
    """
    tool_call_id = tool_runtime.tool_call_id

    return Command(
        update={
            "messages": [
                ToolMessage(
                    tool_call_id=tool_call_id,
                    content=build_tool_call_success_system_feedback(),
                )
            ]
        }
    )
