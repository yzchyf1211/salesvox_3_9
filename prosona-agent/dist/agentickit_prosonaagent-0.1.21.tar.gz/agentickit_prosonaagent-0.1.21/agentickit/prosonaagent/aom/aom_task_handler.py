import json
from typing import (
    Any,
    List,
    Generic,
    cast,
    Callable,
    Awaitable,
    Optional,
)
import uuid
from langchain.agents.middleware.types import (
    StateT,
    ToolCallRequest,
    Command,
    ModelRequest,
    ModelResponse,
    ModelCallResult,
)
from langchain_core.messages import SystemMessage, AnyMessage, ToolCall
from langgraph.runtime import Runtime
from typing_extensions import override

from agentickit.prosonaagent.aom.context import (
    get_prompt_client,
    get_project_context,
    get_activity_context,
)
from agentickit.prosonaagent.aom.state import AOMTaskState, AOMTaskStateT
from agentickit.prosonaagent.aom.tools import (
    next_task,
)
from agentickit.prosonaagent.middleware.session import TaskHandler
from agentickit.prosonaagent.utils.agent_proxy import UserAgentProxy, send_to
from agentickit.prosonaagent.utils.a2a_message import A2ABizDataMessage
from agentickit.prosonaagent.utils.task import get_task_prompt
from agentickit.prosonaagent.utils.time import get_timestamp
from agentickit.prosonaagent.context.common import (
    build_tool_call_success_system_feedback,
)
from .getter import (
    get_next_sco_by_sco_id,
    get_sco_by_sco_id,
    get_activity_by_activity_id,
)
from .api import (
    get_sco_content,
    start_sco,
    end_sco,
    get_sco_history,
)
from .types import AOMCard


class AOMTaskHandler(TaskHandler[AOMTaskStateT], Generic[AOMTaskStateT]):
    name: str
    skills: List[str] = TaskHandler.skills
    state_schema: type[AOMTaskStateT] = cast("type[AOMTaskStateT]", AOMTaskState)
    tools = TaskHandler.tools + [
        next_task,
    ]

    _current_task_messages: Optional[list[AnyMessage]]

    async def aget_card(
        self,
        state: AOMTaskStateT,
        action: str,
        params: Optional[dict[str, Any]] = None,
    ) -> AOMCard:
        """
        - 根据action、params获取卡片信息
        """
        raise NotImplementedError("aget_card is not implemented")

    @override
    async def abefore(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
    ) -> dict[str, Any] | None:
        """
        - 注入当前sco、activity、sco_list信息
        - 注入当前sco TASK.md
        """
        updated = {}

        new_state = await super().abefore(state, runtime, task_id, task_name) or {}
        merged_messages = new_state.get("messages", [])
        updated.update(new_state)

        project_info = state.get("project_info", None)
        project_context = get_project_context(project_info)
        sco = get_sco_by_sco_id(state, task_id)
        activity = get_activity_by_activity_id(state, sco.get("activity_id"))
        sco_list = state.get("activity_sco_list", {}).get(activity.get("id"), [])
        updated["sco"] = sco
        updated["activity"] = activity
        updated["sco_list"] = sco_list

        # 获取当前SCO内容
        sco_segment_list = await get_sco_content(
            state.get("context_id"),
            activity.get("id"),
            sco.get("id"),
            state.get("user_profile"),
        )
        updated["sco_segment_list"] = sco_segment_list

        # 插入项目信息、当前小节信息，给Task Scope使用
        activity_context = get_activity_context(activity, sco_list)
        merged_messages = merged_messages + [
            SystemMessage(content=project_context),
            SystemMessage(content=activity_context),
            SystemMessage(
                content=f"""<current_sco>
    id: {sco.get("id")}
    name: {sco.get("name")}
    type: {sco.get("type")}
</curent_sco>"""
            ),
        ]
        updated["messages"] = merged_messages

        # 插入任务提示
        prompt = get_task_prompt(name=self.name)
        updated.update(new_state)  # ty:ignore[no-matching-overload]
        updated["messages"] = merged_messages + [
            SystemMessage(content=prompt),
        ]

        # 更新SCO状态
        await start_sco(state.get("context_id"), sco.get("id"))

        # 同步SCO生命周期
        history = await get_sco_history(state.get("context_id"), sco.get("id"))
        index = len(history) + 1
        updated["order"] = index

        await send_to(
            agentProxy=UserAgentProxy(state),
            message=A2ABizDataMessage(
                identifier="biz-common-sco-lifecycle",
                params={
                    "type": "aitutor-sco-start",
                    "data": {
                        "mode": "start" if index == 1 else "restart",
                        "sco_id": sco.get("id"),
                        "sco_name": sco.get("name"),
                        "sco_type": sco.get("type"),
                        "activity_id": activity.get("id"),
                        "order": index,
                    },
                },
            ),
            sf_metadata={
                "raw_data": {
                    "sco_id": sco.get("id"),
                    "sco_name": sco.get("name"),
                    "sco_type": sco.get("type"),
                    "activity_id": activity.get("id"),
                    "order": index,
                },
            },
        )

        return updated

    @override
    async def apause(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
    ) -> dict[str, Any] | None:
        sco = state.get("sco")
        activity = state.get("activity")
        order = state.get("order")
        new_state = await super().apause(state, runtime, task_id, task_name) or {}

        # 同步SCO生命周期
        await send_to(
            agentProxy=UserAgentProxy(state),
            message=A2ABizDataMessage(
                identifier="biz-common-sco-lifecycle",
                params={
                    "type": "aitutor-sco-pause",
                    "data": {
                        "mode": "pause",
                        "sco_id": sco.get("id"),
                        "sco_name": sco.get("name"),
                        "sco_type": sco.get("type"),
                        "activity_id": activity.get("id"),
                        "order": order,
                    },
                },
            ),
            sf_metadata={
                "raw_data": {
                    "sco_id": sco.get("id"),
                    "sco_name": sco.get("name"),
                    "sco_type": sco.get("type"),
                    "activity_id": activity.get("id"),
                    "order": order,
                },
            },
        )

        return {
            **new_state,
            "interrupted": True,
        }

    @override
    async def aresume(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
        **kwargs: Any,  # 支持no_speak参数，表示不欢迎用户，停留在之前的对话状态
    ) -> dict[str, Any] | None:
        sco = state.get("sco")
        activity = state.get("activity")
        order = state.get("order")
        new_state = await super().aresume(state, runtime, task_id, task_name) or {}

        # 插入恢复上下文
        if kwargs.get("no_speak"):
            new_state["interrupted"] = True
        else:
            client = get_prompt_client(prompt_name="commands/resume")
            new_state["messages"] = new_state.get("messages", []) + [
                SystemMessage(content=client.compile(timestamp=get_timestamp())),
            ]

        # 同步SCO生命周期
        await send_to(
            agentProxy=UserAgentProxy(state),
            message=A2ABizDataMessage(
                identifier="biz-common-sco-lifecycle",
                params={
                    "type": "aitutor-sco-resume",
                    "data": {
                        "mode": "start",
                        "sco_id": sco.get("id"),
                        "sco_name": sco.get("name"),
                        "sco_type": sco.get("type"),
                        "activity_id": activity.get("id"),
                        "order": order,
                    },
                },
            ),
            sf_metadata={
                "raw_data": {
                    "sco_id": sco.get("id"),
                    "sco_name": sco.get("name"),
                    "sco_type": sco.get("type"),
                    "activity_id": activity.get("id"),
                    "order": order,
                },
            },
        )

        return new_state

    @override
    async def aafter(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
        is_interrupt: bool,
    ) -> dict[str, Any] | None:
        sco = state.get("sco")
        activity = state.get("activity")
        order = state.get("order")

        new_state = (
            await super().aafter(state, runtime, task_id, task_name, is_interrupt) or {}
        )

        # 同步SCO生命周期
        await send_to(
            agentProxy=UserAgentProxy(state),
            message=A2ABizDataMessage(
                identifier="biz-common-sco-lifecycle",
                params={
                    "type": "aitutor-sco-end",
                    "data": {
                        "mode": "end",
                        "sco_id": sco.get("id"),
                        "sco_name": sco.get("name"),
                        "sco_type": sco.get("type"),
                        "activity_id": activity.get("id"),
                        "order": order,
                    },
                },
            ),
            sf_metadata={
                "raw_data": {
                    "sco_id": sco.get("id"),
                    "sco_name": sco.get("name"),
                    "sco_type": sco.get("type"),
                    "activity_id": activity.get("id"),
                    "order": order,
                },
            },
        )
        # 更新SCO状态
        await end_sco(
            state.get("context_id"), sco.get("id"), self._current_task_messages or []
        )

        return new_state

    @override
    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        self._current_task_messages = request.messages
        sco = request.state.get("sco")

        result = await super().awrap_model_call(request, handler)

        messages = result.result
        replaced_messages = []
        for message in messages:
            if (
                message.type == "ai" and message.tool_calls  # ty:ignore[unresolved-attribute]
            ):
                replaced_tool_calls = []
                for tool_call in message.tool_calls:  # ty:ignore[unresolved-attribute]
                    # 将next_task替换为_builtin_end_task和_builtin_start_task
                    if tool_call.get("name") == "next_task":
                        next_sco = get_next_sco_by_sco_id(
                            request.state,  # ty:ignore[invalid-argument-type]
                            sco.get("id"),  # ty:ignore[invalid-argument-type]
                        )
                        replaced_tool_calls.append(
                            ToolCall(
                                name="_builtin_end_task",
                                id=f"call_{uuid.uuid4().hex[:22]}",
                                args={"is_interrupt": False},
                            )
                        )
                        if next_sco:
                            replaced_tool_calls.append(
                                ToolCall(
                                    name="_builtin_start_task",
                                    id=f"call_{uuid.uuid4().hex[:22]}",
                                    args={
                                        "id": next_sco.get("id"),
                                        "name": next_sco.get("type"),
                                    },
                                )
                            )
                    else:
                        replaced_tool_calls.append(tool_call)

                replaced_messages.append(
                    message.model_copy(update={"tool_calls": replaced_tool_calls})
                )
            else:
                replaced_messages.append(message)

        result.result = replaced_messages

        return result

    @override
    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[Command]],
    ) -> Command:
        order = request.state.get("order")
        tool_call = request.tool_call
        if tool_call.get("name") == "send_user_content":
            action = request.tool_call.get("args", {}).get("action", "")
            params = request.tool_call.get("args", {}).get("params", {})
            user = UserAgentProxy(request.state)
            sco = get_sco_by_sco_id(request.state, request.state.get("current_task_id"))

            await send_to(
                agentProxy=user,
                message=A2ABizDataMessage(
                    identifier="biz-common-activity-introduction",
                    params={
                        "type": "aitutor-action-introduction",
                        "data": {"type": "sco"},
                    },
                ),
                sf_metadata={
                    "raw_data": {
                        "sco_id": sco.get("id"),
                        "sco_name": sco.get("name"),
                        "sco_type": sco.get("type"),
                        "activity_id": sco.get("activity_id"),
                        "order": order,
                    }
                },
            )

            card = await self.aget_card(request.state, action, params)
            # show_study_index = card.get("show_study_index", True)
            command = cast(Command, await handler(request))
            update = command.update
            update["messages"][0].content = build_tool_call_success_system_feedback(
                f"user can see the content: {card.get('description') or json.dumps(card.get('data'), ensure_ascii=False)}"
            )
            update["messages"][0].additional_kwargs = {
                **update["messages"][0].additional_kwargs,
                "__content_type__": card.get("type"),
                "__card__": card,
            }
            command = Command(update=update)

            # title = f"{sco.get('name')}{('-第' + str(order) + '次') if show_study_index else ''}-{card.get('name')}"  # 格式，{sco_name}-{index(optional)}-{action}，如任务委派-第一次-演练记录
            title = f"{sco.get('name')}-{card.get('name')}"  # 暂时不支持order
            await send_to(
                agentProxy=user,
                message=A2ABizDataMessage(
                    identifier="biz-common-sco-display",
                    params={
                        "type": "aitutor-sco",
                        "data": {
                            "sco_id": sco.get("id"),
                            "sco_name": sco.get("name"),
                            "sco_type": sco.get("type"),
                            "card": {
                                "id": card.get("id"),
                                "type": card.get("type"),
                                "title": title,
                                "data": card.get("data"),
                            },
                        },
                    },
                ),
                sf_metadata={
                    "search_text_1": title,
                    "filter_keyword_1": card.get("type"),
                    "raw_data": {
                        "sco_id": sco.get("id"),
                        "sco_name": sco.get("name"),
                        "sco_type": sco.get("type"),
                        "activity_id": sco.get("activity_id"),
                        "order": order,
                    },
                },
            )

            return command

        return await handler(request)
