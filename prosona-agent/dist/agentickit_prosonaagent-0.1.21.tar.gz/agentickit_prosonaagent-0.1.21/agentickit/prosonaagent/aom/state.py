from typing import Optional, List, Dict, TypeVar

from agentickit.prosonaagent.aom.types import (
    ProjectSchema,
    ProjectModuleSchema,
    ActivityExtendSchema,
    SCOExtendSchema,
    SCOSegmentSchema,
)
from agentickit.prosonaagent.middleware.session import SessionState


class AOMSessionState(SessionState):
    """AOM Session状态定义"""

    project_id: Optional[str]  # 项目id
    project_info: Optional[ProjectSchema]  # 当前项目的基本信息
    module_list: List[ProjectModuleSchema]  # 项目包含的所有模块
    activity_list: List[ActivityExtendSchema]  # 所有小节信息
    activity_sco_list: Dict[str, List[SCOExtendSchema]]  # 所有小节对应的SCO列表
    ended: Optional[bool]  # 项目是否结束


AOMStateT = TypeVar("AOMStateT", bound=AOMSessionState)


class AOMTaskState(AOMSessionState):
    """AOM Task状态定义"""

    sco: SCOExtendSchema
    activity: ActivityExtendSchema
    sco_list: List[SCOExtendSchema]
    sco_segment_list: List[SCOSegmentSchema]
    order: int  # 第几次学习


AOMTaskStateT = TypeVar("AOMTaskStateT", bound=AOMTaskState)
