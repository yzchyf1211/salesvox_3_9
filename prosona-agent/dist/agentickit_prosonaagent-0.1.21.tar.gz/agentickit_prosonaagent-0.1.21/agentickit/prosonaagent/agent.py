from typing import List
from langgraph.graph.state import CompiledStateGraph
from langchain.agents import create_agent
from langchain.agents.middleware.types import AgentMiddleware
from langchain.agents.middleware.model_fallback import ModelFallbackMiddleware
from langchain_core.messages import SystemMessage
from agentickit.core.infra.config.loader import get_config
from agentickit.core.infra.models import get_model

from agentickit.prosonaagent.tools import (
    _builtin_conversation,
    _builtin_end_task,
    _builtin_start_task,
    _builtin_get_skill_information,
    _builtin_get_skill_resource,
    _builtin_wait_system_feedback,
    _builtin_write_scratchpad,
)
from agentickit.prosonaagent.middleware.session import (
    SessionHandler,
    TaskHandler,
    ProsonaAgentSessionMiddleware,
)

from agentickit.prosonaagent.state import State


def create_prosona_agent(
    model: str = None,
    fallback_models: List[str] = [],
    system_prompt: str | SystemMessage | None = None,
    session_handler: SessionHandler | None = None,
    task_handlers: List[TaskHandler] = [],
    middleware: List[AgentMiddleware] = [],
) -> CompiledStateGraph:
    """创建Prosona Agent"""
    model = get_model(model or get_config("model_groups.main.primary_model"))

    # agent的工具：仅包含builtin工具，业务工具通过session_handler和task_handlers扩展
    agent_tools = [
        _builtin_conversation,
        _builtin_wait_system_feedback,
        _builtin_start_task,
        _builtin_end_task,
        _builtin_get_skill_information,
        _builtin_get_skill_resource,
        _builtin_write_scratchpad,
    ]

    # 多语言fallback模型
    fallback_models = (
        [get_model(get_config("model_groups.main.fallback_model"))]
        if not fallback_models
        else fallback_models
    )

    # 扩展middleware再原有middleware之后调用
    agent_middlewares = [
        *middleware,
        ProsonaAgentSessionMiddleware(session_handler, task_handlers),
        ModelFallbackMiddleware(*fallback_models),
    ]

    return create_agent(
        model=model,
        system_prompt=system_prompt,
        state_schema=State,
        tools=agent_tools,
        middleware=agent_middlewares,
    )
