import uuid
import logging
import re
from typing import AsyncIterable, Any

from agentickit.core.server import StandardStreamAgenticHandler
from agentickit.core.server.context import (
    ExecutionContext,
    ExecutionStatus,
    execution_store,
)
from agentickit.langgraph import get_default_runnable_config
from agentickit.langgraph.checkpoint import async_checkpoint_saver
from agentickit.langgraph.stream import build_from_astream_event
from langchain_core.runnables import RunnableConfig
from langgraph.graph.state import CompiledStateGraph
from langgraph.types import Command
from agentickit.core.server.types import A2APartType

logger = logging.getLogger(__name__)


def _is_stream_text_tool_call(name: str) -> bool:
    return name == "_builtin_conversation"


def _extract_args_from_incomplete_json(json_string: str, key: str) -> str:
    """从可能不完整的JSON字符串中提取关键参数"""
    # 目前Agent会返回非标的文本内容
    # text: "你能抓住‘飞行中换翅膀’这个比喻，说明你已经理解了转型的艰难和必须边做边学的现实。”}"
    # 流式输出会出现”}分开输出的情况，需要处理当只输出”，让外部不做流式输出
    if json_string.endswith("”"):
        raise ValueError(f"JSON字符串最后包含多余的右引号: {json_string}")

    # 提取type字段
    match = re.search(rf'"{key}"\s*:\s*"([^"]*)', json_string)
    if not match:
        return None

    value = match.group(1)
    # 如果字符串最后包含多余的右大括号，去掉它
    if value.endswith("”}"):
        value = value[:-2]
    return value


class ProsonaA2AStreamAgenticExecutor(StandardStreamAgenticHandler):
    """
    A2A流式Agent执行器抽象基类

    定义了A2A流式Agent执行器的标准接口，所有具体的A2A流式Agent执行器实现都应该继承此类。
    提供了流式处理用户请求的抽象方法，支持异步迭代器模式。
    """

    def __init__(self, graph: CompiledStateGraph):
        self.graph = graph

    async def stream(
        self, state: Any, context: ExecutionContext
    ) -> AsyncIterable[dict[str, Any]]:
        """
        流式处理方法

        这是智能体的核心执行方法，处理用户输入并返回流式响应。

        参数：
            state: 当前状态，包含用户消息和上下文信息
            context: 执行上下文，包含配置和元数据

        返回：
            AsyncIterable[A2AMessageChunk]: 流式输出的消息块

        处理流程：
        1. 获取运行配置
        2. 检查是否有中断需要恢复
        3. 流式执行智能体图
        4. 处理各种事件（模型输出、工具调用等）
        5. 返回流式结果
        """
        logger.info(f"开始处理请求，context_id: {state.get('context_id')}")

        # 获取默认运行配置
        config: RunnableConfig = get_default_runnable_config(context)
        # 增加递归限制，防止复杂流程超过默认的100次限制
        config["recursion_limit"] = 100

        # 文本缓冲区，用于累积模型输出
        tool_call_name = ""
        tool_call_text = ""
        tool_call_chunks_buffer = ""
        conversation_buffer = ""
        data_buffer = ""
        # 检查是否有需要恢复的中断
        cached_execution = execution_store.load(state["context_id"])
        inputs = (
            Command(resume=state)
            if cached_execution
            and cached_execution["status"] == ExecutionStatus.INTERRUPT
            else state
        )

        if not self.graph.checkpointer:
            self.graph.checkpointer = async_checkpoint_saver()

        # 流式执行智能体图
        # astream_events 提供实时的事件流
        async for event in self.graph.astream_events(inputs, config, debug=True):
            # 使用 agentickit 提供的辅助函数构建输出数据
            data = build_from_astream_event(event)

            # 示例：检测到特定条件时中断循环
            # 可以根据需要添加中断条件，例如：
            # 1. 检测到特定工具调用
            # 2. 检测到特定状态
            # 3. 检测到错误或异常
            # if some_condition:
            #     logger.info("检测到中断条件，退出循环")
            #     break

            # 处理聊天模型流式输出事件
            if event.get("event") == "on_chat_model_stream":
                chunk = event.get("data", {}).get("chunk")
                # 流式对话输出
                if "conversation" in event.get("tags", []):
                    delta = event["data"].get("chunk", None)
                    if delta and hasattr(delta, "content"):
                        if delta.content:
                            data["content"] = delta.content
                            data["append"] = True if conversation_buffer else False
                            data["last_chunk"] = False
                            # 添加speaker信息
                            speaker = event.get("metadata", {}).get("speaker")
                            if speaker:
                                # see https://alidocs.dingtalk.com/i/nodes/amweZ92PV6vZ0PNQFeKe3K9wVxEKBD6p?cid=71024304715&utm_source=im&utm_scene=team_space&iframeQuery=utm_medium%3Dim_card%26utm_source%3Dim&utm_medium=im_card&corpId=ding23a92d4eb3bf631f
                                # see agentickit EnhancedAgenticExecutor._process
                                data["metadata"] = {
                                    **data.get("metadata", {}),
                                    "sender": speaker.get("sender"),
                                    "ttsConfig": speaker.get("ttsConfig"),
                                    "isCustomTTS": speaker.get("isCustomTTS"),
                                }
                            conversation_buffer += delta.content
                            yield data

                # 流式data输出
                if "data" in event.get("tags", []):
                    delta = event["data"].get("chunk", None)
                    if delta and hasattr(delta, "content"):
                        if delta.content:
                            data["part_type"] = A2APartType.DATA
                            data["partType"] = A2APartType.DATA
                            data["content_type"] = A2APartType.DATA.value
                            tool_name = event.get("metadata", {}).get("tool_name")
                            if not data_buffer:
                                data["content"] = {
                                    "type": "tool",
                                    "identifier": "tool-call",
                                    "name": tool_name,
                                    "id": f"call_{uuid.uuid4().hex[:22]}",
                                    "index": 0,
                                    "args": delta.content,
                                }
                            else:
                                data["content"] = {"args": delta.content}
                            data["part_metadata"] = {
                                **data.get("part_metadata", {}),
                                "execEnv": "frontend",
                            }

                            data["append"] = True if data_buffer else False
                            data["last_chunk"] = False
                            # 添加speaker信息
                            speaker = event.get("metadata", {}).get("speaker")
                            if speaker:
                                data["metadata"] = {
                                    **data.get("metadata", {}),
                                    "speaker": speaker,
                                }
                            data_buffer += delta.content
                            yield data

                if hasattr(chunk, "tool_call_chunks") and chunk.tool_call_chunks:
                    tool_call_chunk = chunk.tool_call_chunks[0]
                    name = tool_call_chunk.get("name")

                    # 开始发送PART_START和设置工具调用名称、文本、缓冲区
                    is_stream_start = bool(name)
                    # 一次LLM请求多个工具调用，is_stream_end条件无法触发，需要根据开始新工具来触发PART_END
                    # 为什么有两段重复的逻辑，因为is_stream_end不一定触发，通过触发后清空tool_call_name来避免重复执行
                    if is_stream_start and _is_stream_text_tool_call(tool_call_name):
                        data["append"] = True
                        data["last_chunk"] = True
                        data["is_yield_data"] = True
                        yield data

                    if is_stream_start:
                        tool_call_name = name
                        tool_call_text = ""
                        tool_call_chunks_buffer = ""

                    if _is_stream_text_tool_call(tool_call_name):
                        args = tool_call_chunk.get("args")
                        if args:
                            tool_call_chunks_buffer += args or ""
                        try:
                            text = (
                                _extract_args_from_incomplete_json(
                                    tool_call_chunks_buffer, "text"
                                )
                                or ""
                            )
                            is_first = len(tool_call_text) == 0
                            delta = text[len(tool_call_text) :]
                            tool_call_text = text
                            if delta:
                                if is_first:
                                    data["append"] = False
                                    data["is_yield_data"] = True
                                data["content"] = delta
                                data["metadata"] = event.get("metadata", {}).get(
                                    "user_data", {}
                                )
                                yield data
                        except Exception as e:
                            logger.warning(
                                f"[ProsonaA2AStreamAgenticExecutor] 处理_extract_args_from_incomplete_json时出错: event={event.get('event')}, error={e}",
                                exc_info=True,
                            )

                # 结束发送PART_END和清空工具调用名称、文本、缓冲区
                # 一次LLM请求结束，最后一个工具是对话工具
                is_stream_end = len(chunk.tool_call_chunks) == 0
                if is_stream_end and _is_stream_text_tool_call(tool_call_name):
                    data["append"] = True
                    data["last_chunk"] = True
                    data["is_yield_data"] = True
                    yield data

                if is_stream_end:
                    tool_call_name = ""
                    tool_call_text = ""
                    tool_call_chunks_buffer = ""

            elif event["event"] == "on_chat_model_start":
                conversation_buffer = ""
                data_buffer = ""

            elif event["event"] == "on_chat_model_end":
                conversation_buffer = ""
                data_buffer = ""

                if "conversation" in event.get("tags", []) or "data" in event.get(
                    "tags", []
                ):
                    data["append"] = True
                    data["last_chunk"] = True
                    if "data" in event.get("tags", []):
                        data["part_type"] = A2APartType.DATA
                        data["partType"] = A2APartType.DATA
                        data["content_type"] = A2APartType.DATA.value
                        data["content"] = {}
                    yield data
            elif (
                event["event"] in ["on_chain_end"]
                and event["name"] == "LangGraph"
                and len(event["parent_ids"]) == 0
            ):
                yield data
                # 如果需要在此处中断循环，可以添加 break
                # break

        logger.info(f"请求处理完成，context_id: {state.get('context_id')}")
