import json
from typing import Literal, Optional, Any

from langchain_core.messages import BaseMessage

from agentickit.prosonaagent.utils.time import get_timestamp


def build_message_additional_kwargs(
    role: Literal["assistant", "user"],
    name: Optional[str] = None,
    avatar: Optional[str] = None,
    content_type: str = "text",
    text: Optional[str] = None,
    card: Optional[dict] = None,
) -> dict[str, Any]:
    return {
        "__role__": role,
        "__name__": name,
        "__avatar__": avatar,
        "__content_type__": content_type,
        "__text__": text,
        "__card__": card,
        "__timestamp__": get_timestamp(),
    }


# 将messages转换为chat_history
def format_chat_history(messages: list[BaseMessage]) -> str:
    """
    获取历史对话
    """
    chat_history = []
    for message in messages:
        timestamp = message.additional_kwargs.get("timestamp", "")
        if message.additional_kwargs.get("__role__") == "assistant":
            if message.additional_kwargs.get("__text__"):
                chat_history.append(
                    f'[{timestamp}] {message.additional_kwargs.get("__name__", "you")} say: "{message.additional_kwargs.get("__text__", "")}"'
                )
            if message.additional_kwargs.get("__card__"):
                content = message.additional_kwargs.get("__card__", {}).get(
                    "description", ""
                ) or json.dumps(
                    message.additional_kwargs.get("__card__", {}).get("data", {}),
                    ensure_ascii=False,
                )
                chat_history.append(
                    f"[{timestamp}] {message.additional_kwargs.get('__name__', 'you')} send content to user: {content}"
                )

        if message.additional_kwargs.get(
            "__role__"
        ) == "user" and message.additional_kwargs.get("__text__"):
            chat_history.append(
                f'[{timestamp}] user say: "{message.additional_kwargs.get("__text__", "")}"'
            )

    return "\n\n".join(chat_history)
