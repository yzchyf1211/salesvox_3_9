from typing import Dict, Any, TypedDict, Optional, Literal
from .a2a_message import A2AMessage
from agentickit.prosonaagent.state import State


class Sender(TypedDict):
    name: str
    avatar: str


class TTSConfig(TypedDict):
    vendor: Literal["ali", "bytedance", "google"]

    voice: str

    # 音频格式
    # 阿里：   'pcm' | 'wav' | 'mp3'
    # 字节：   'pcm' | 'mp3' | 'ogg_opus'
    # google: 'pcm' | 'mp3' | 'ogg_opus'
    format: str

    # 采样率
    # 阿里：8000 | 16000(default) | 24000
    # 字节：8000 | 16000 | 22050 | 24000（default） | 32000 | 44100 | 48000
    # google: 24000(default)
    sampleRate: int

    # 语速
    # 阿里： -500 ~ 500
    # 字节： 0.2  ~ 3
    # google： 0.25 - 4.0
    speechRate: int

    # 语调
    # 阿里： -500 ~ 500   default 0
    # 字节：  没有支持
    # google: 语调 (-20.0 - 20.0)
    pitchRate: int

    # 音量
    # 阿里： 0-100   default 50
    # 字节： 0.1 ~ 3   default 1
    # google: -96 ~ 16  default 0
    volume: int


class Speaker(TypedDict):
    sender: Sender
    ttsConfig: TTSConfig
    isCustomTTS: bool


class SearchAndFilterMetadata(TypedDict):
    search_text_1: Optional[str] = None
    search_text_2: Optional[str] = None
    search_text_3: Optional[str] = None
    search_text_4: Optional[str] = None
    search_text_5: Optional[str] = None
    filter_keyword_1: Optional[str] = None
    filter_keyword_2: Optional[str] = None
    filter_keyword_3: Optional[str] = None
    filter_keyword_4: Optional[str] = None
    filter_keyword_5: Optional[str] = None
    raw_data: Optional[Dict[str, Any]] = None


class AgentProxy:
    def __init__(self) -> None:
        pass

    @staticmethod
    async def sendTo(
        agentProxy,
        message: A2AMessage,
        metadata: Dict[str, Any] = {},
        part_metadata: Dict[str, Any] = {},
        message_id: str | None = None,
    ) -> None:
        return await agentProxy.onMessage(
            message,
            metadata=metadata,
            part_metadata=part_metadata,
            message_id=message_id,
        )

    async def onMessage(
        self,
        message: A2AMessage,
        metadata: Dict[str, Any] = {},
        part_metadata: Dict[str, Any] = {},
        message_id: str | None = None,
    ) -> None:
        pass


class UserAgentProxy(AgentProxy):
    """
    定义用户输入解析类
    """

    def __init__(self, state: State) -> None:
        self.state = state
        self.context_id = state.get("context_id")

        text_part_size = state.get("text_part_size", 0)
        if text_part_size == 0 and state.get("parts"):
            # 支持Mock的Dict数据
            part = state.get("parts", [])[-1]
            action_data = (
                part.root.data
                if hasattr(part, "root")
                else part.get("root", {}).get("data", {})
            )
            self.action = action_data.get("actionName")
            self.params = action_data.get("params", {})

    def get_action(self):
        return self.action if hasattr(self, "action") else None

    def get_params(self):
        return self.params if hasattr(self, "params") else None

    def get_context_id(self):
        return self.context_id

    def when_do(self, action: str) -> bool:
        return self.action == action if hasattr(self, "action") else False

    async def on_message(
        self,
        message: A2AMessage,
        metadata: Dict[str, Any] = {},
        part_metadata: Dict[str, Any] = {},
        message_id: str | None = None,
    ) -> None:
        return await message.send_to(
            self.context_id,
            metadata=metadata,
            part_metadata=part_metadata,
            message_id=message_id,
        )


async def send_to(
    agentProxy: AgentProxy,
    message: A2AMessage,
    speaker: Optional[Speaker] = {},
    sf_metadata: Optional[SearchAndFilterMetadata] = {},
    message_id: str | None = None,
):
    return await agentProxy.on_message(
        message,
        metadata={
            "sender": speaker.get("sender"),
            "ttsConfig": speaker.get("ttsConfig"),
        },
        part_metadata={
            **sf_metadata,
        },
        message_id=message_id,
    )
