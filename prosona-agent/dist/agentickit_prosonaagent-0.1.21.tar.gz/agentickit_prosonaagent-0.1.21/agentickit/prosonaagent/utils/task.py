from typing import Optional
from agentickit.core.infra.langfuse.prompt import get_prompt, get_prompt_langfuse
from agentickit.core.infra.config.loader import get_config


def get_task_namespace_by_name(task_name: str) -> Optional[str]:
    """
    根据任务名称从配置中查找对应的 namespace

    Args:
        task_name: 任务名称

    Returns:
        对应的 namespace，如果找不到则返回 None
    """
    location_ids = get_config("prompts.tasks.location_ids", default=[])
    if not location_ids:
        return None

    # 读取所有 locations 配置（TOML 数组配置）
    locations = get_config("prompts.tasks.locations", default=[])
    if not locations:
        return None

    # 确保 locations 是列表
    if not isinstance(locations, list):
        locations = [locations]

    # 遍历所有 locations 查找包含该 task 的配置
    for location_id in location_ids:
        for loc in locations:
            # 处理字典格式的配置
            if isinstance(loc, dict) and loc.get("id") == location_id:
                tasks = loc.get("tasks", [])
                if task_name in tasks:
                    return loc.get("namespace")

    return None


def get_task_prompt(name: str, namespace: Optional[str] = None) -> str:
    """
    获取任务提示

    Args:
        name: 任务名称
        namespace: 命名空间，如果为 None 则从配置中自动查找

    Returns:
        编译后的任务提示内容
    """
    # 如果未提供 namespace，从配置中查找
    if namespace is None:
        namespace = get_task_namespace_by_name(name)
        if namespace is None:
            raise ValueError(
                f"无法找到任务 '{name}' 对应的 namespace，请检查配置或显式提供 namespace"
            )

    client = get_prompt_langfuse(namespace)
    prompt = get_prompt(name=f"tasks/{name}/TASK.md", langfuse_client=client)
    return prompt.compile()
