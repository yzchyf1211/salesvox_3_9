LANGUAGE_NAMES = {
    "zh_CN": "Chinese Simplified",
    "zh_TW": "Chinese Traditional",
    "ja": "Japanese",
    "en": "English",
}


def get_language_name(lang: str) -> str:
    return LANGUAGE_NAMES.get(lang, "Unknown")
