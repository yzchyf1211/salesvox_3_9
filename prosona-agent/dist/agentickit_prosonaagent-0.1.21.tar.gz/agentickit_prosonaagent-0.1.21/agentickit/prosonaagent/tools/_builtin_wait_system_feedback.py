from langchain_core.tools import tool

from langgraph.prebuilt import ToolRuntime
from langgraph.types import Command

from langchain_core.messages import ToolMessage
from agentickit.prosonaagent.context.common import (
    build_tool_call_success_system_feedback,
)


@tool
async def _builtin_wait_system_feedback(
    tool_runtime: ToolRuntime,
) -> Command:
    """
    wait system feedback
    """
    tool_call_id = tool_runtime.tool_call_id

    return Command(
        update={
            "messages": [
                ToolMessage(
                    content=build_tool_call_success_system_feedback(),
                    tool_call_id=tool_call_id,
                )
            ]
        }
    )
