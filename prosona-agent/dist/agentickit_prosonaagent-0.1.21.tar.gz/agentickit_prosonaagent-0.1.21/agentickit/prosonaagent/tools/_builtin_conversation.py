from typing import Optional
from langchain_core.tools import tool
from langgraph.types import Command
from langgraph.prebuilt import ToolRuntime
from langchain_core.messages import ToolMessage

from agentickit.prosonaagent.context.common import (
    build_tool_call_success_system_feedback,
)


@tool
async def _builtin_conversation(
    text: str,
    ask_question: bool,
    tool_runtime: ToolRuntime = None,
) -> Command:
    """
    conversation with user

    Args:
        text: the content of the conversation
        ask_question: whether the conversation includes asking a question
    """
    tool_call_id = tool_runtime.tool_call_id

    return Command(
        update={
            "messages": [
                ToolMessage(
                    content=build_tool_call_success_system_feedback(
                        "user has seen what you said"
                    ),
                    tool_call_id=tool_call_id,
                ),
            ]
        }
    )
