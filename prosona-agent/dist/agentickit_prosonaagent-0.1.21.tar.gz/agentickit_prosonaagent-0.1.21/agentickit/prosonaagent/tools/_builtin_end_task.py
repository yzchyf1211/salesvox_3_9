from typing import Optional
from langchain_core.tools import tool

from langgraph.prebuilt import ToolRuntime
from langgraph.types import Command
from langchain_core.messages import ToolMessage

from agentickit.prosonaagent.context.common import (
    build_tool_call_success_system_feedback,
)


@tool
async def _builtin_end_task(
    is_interrupt: bool,
    interrupt_reason: Optional[str] = None,
    tool_runtime: ToolRuntime = None,
) -> Command:
    """
    end task

    Args:
        is_interrupt: whether the task is interrupted
        interrupt_reason: the reason of the interruption, required when is_interrupt is True
    """
    tool_call_id = tool_runtime.tool_call_id

    return Command(
        update={
            "messages": [
                ToolMessage(
                    content=build_tool_call_success_system_feedback(),
                    tool_call_id=tool_call_id,
                ),
            ]
        }
    )
