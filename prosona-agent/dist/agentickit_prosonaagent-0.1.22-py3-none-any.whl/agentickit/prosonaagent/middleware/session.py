from typing import (
    Awaitable,
    Callable,
    Literal,
    Any,
    cast,
    Optional,
    List,
    Generic,
    Annotated,
)
from typing_extensions import override
from langchain_core.messages import (
    ToolMessage,
    HumanMessage,
    RemoveMessage,
    SystemMessage,
    AnyMessage,
)
from langgraph.types import Command
from langchain.agents.middleware.types import (
    ModelRequest,
    ModelResponse,
    ModelCallResult,
    hook_config,
    StateT,
)
from langchain.agents.middleware.types import (
    AgentMiddleware,
    ToolCallRequest,
)
from langgraph.runtime import Runtime
from agentickit.core.exception import AgenticException
from agentickit.core.infra.skills.manager import (
    get_skills_by_names,
)
from agentickit.core.infra.config.loader import get_config
from agentickit.core.infra.models import get_model
from agentickit.prosonaagent.context.common import (
    build_human_message_content,
    build_skill_information_context_list,
    build_skill_system_prompt,
)
from agentickit.prosonaagent.utils.agent_proxy import UserAgentProxy
from agentickit.prosonaagent.state import State
from agentickit.prosonaagent.utils.user import get_user_profile
from agentickit.prosonaagent.utils.message import build_message_additional_kwargs
from agentickit.prosonaagent.tools import (
    _builtin_start_task,
    _builtin_end_task,
    _builtin_get_skill_information,
    _builtin_get_skill_resource,
)
from agentickit.prosonaagent.utils.i18n import get_language_name


def replace_reducer(current: Any, new: Any) -> Any:
    """覆盖 reducer：总是返回新值，直接覆盖旧值"""
    return new


class SessionState(State):
    """Prosona AOM Agent状态定义"""

    initialized: Optional[bool]
    current_scope: Annotated[Literal["session", "task"], replace_reducer]
    current_task_id: Annotated[Optional[str], replace_reducer]
    current_task_name: Annotated[Optional[str], replace_reducer]
    interrupted: Optional[bool]


class SessionHandler(Generic[StateT]):
    """
    Session处理类，支持Session、Task、SCO的切换

    1. 用户输入处理
    2. 会话开始、暂停、继续处理
    3. 任务开始、结束处理
    4. 改写模型调用
    """

    skills: List[str] = ["manage_task"]
    tools = [
        _builtin_start_task,
        _builtin_get_skill_information,
        _builtin_get_skill_resource,
    ]

    state_schema: type[StateT] = cast("type[StateT]", SessionState)

    async def aafter_user_input(
        self,
        state: StateT,
        runtime: Runtime,
        user_input: str,
        action: Optional[str],
        params: Optional[dict[str, Any]],
    ) -> dict[str, Any] | None:
        pass

    async def abefore_task(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
    ) -> dict[str, Any] | None:
        pass

    async def aafter_task(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
        is_interrupt: bool,
    ) -> dict[str, Any] | None:
        pass

    async def abefore_session(
        self, state: StateT, runtime: Runtime
    ) -> dict[str, Any] | None:
        pass

    async def apause_session(
        self, state: StateT, runtime: Runtime
    ) -> dict[str, Any] | None:
        pass

    async def aresume_session(
        self, state: StateT, runtime: Runtime
    ) -> dict[str, Any] | None:
        pass

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        return await handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[Command]],
    ) -> Command:
        return await handler(request)


class TaskHandler(Generic[StateT]):
    name: str
    skills: List[str] = ["manage_task"]
    tools = [
        _builtin_get_skill_information,
        _builtin_get_skill_resource,
        _builtin_end_task,
    ]
    state_schema: type[StateT] = cast("type[StateT]", SessionState)
    model_group: str = "main"
    primary_model: Optional[str] = None
    fallback_models: Optional[List[str]] = None

    async def aafter_user_input(
        self,
        state: StateT,
        runtime: Runtime,
        user_input: str,
        action: Optional[str],
        params: Optional[dict[str, Any]],
    ) -> dict[str, Any] | None:
        pass

    async def abefore(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
    ) -> dict[str, Any] | None:
        pass

    async def aafter(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
        is_interrupt: bool,
    ) -> dict[str, Any] | None:
        pass

    async def apause(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
    ) -> dict[str, Any] | None:
        pass

    async def aresume(
        self,
        state: StateT,
        runtime: Runtime,
        task_id: str,
        task_name: str,
    ) -> dict[str, Any] | None:
        pass

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        # Try primary model first
        last_exception: Exception
        try:
            if not self.primary_model:
                self.primary_model = get_config(
                    f"model_groups.{self.model_group}.primary_model"
                )
            return await handler(request.override(model=get_model(self.primary_model)))
        except Exception as e:  # noqa: BLE001
            last_exception = e

        # Try fallback models
        if not self.fallback_models:
            self.fallback_models = [
                get_config(f"model_groups.{self.model_group}.fallback_model")
            ]
        for fallback_model in self.fallback_models:
            try:
                return await handler(request.override(model=get_model(fallback_model)))
            except Exception as e:  # noqa: BLE001
                last_exception = e
                continue

        raise last_exception

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[Command]],
    ) -> Command:
        return await handler(request)


class ProsonaAgentSessionMiddleware(AgentMiddleware[SessionState, Any]):
    """Session中间件

    1. 消息压缩：
    根据current_scope做上下文隔离

    2. 统一标记Message，增加额外参数：
    __role__：assistant 或者 user，框架内处理
    __avatar__：角色头像，可选
    __name__：角色名称，可选
    __content_type__：内容消息对应的类型，包含聊天、卡片，Literal["text", "content", "report"]，必填
    __text__：聊天内容，text类型必填
    __card__：卡片内容，非text类型必填
    __scope__：主还是子Agent，session、task，框架内处理
    __task_id__：任务运行id，对应sco_id，框架内处理
    __task_name__：任务名称，对应sco_name，框架内处理
    __timestamp__：消息时间戳，框架内处理
    """

    state_schema = SessionState

    def __init__(
        self,
        session_handler: SessionHandler | None,
        task_handlers: List[TaskHandler] | None,
    ) -> None:
        # 维护当前Scope
        self._session_handler = session_handler
        self._task_handlers = task_handlers or []

        # 扩展session的state_schema - 动态合并多个state schemas
        bases = [SessionState]
        if (
            session_handler
            and hasattr(session_handler, "state_schema")
            and session_handler.state_schema
        ):
            if session_handler.state_schema not in bases:
                bases.append(session_handler.state_schema)

        for task_handler in self._task_handlers:
            if (
                task_handler
                and hasattr(task_handler, "state_schema")
                and task_handler.state_schema
            ):
                if task_handler.state_schema not in bases:
                    bases.append(task_handler.state_schema)

        # 如果有多个基类，创建合并后的类
        if len(bases) > 1:
            self.state_schema = type("MergedSessionState", tuple(bases), {})
        else:
            self.state_schema = SessionState

        # 扩展tools，去重处理（按tool.name去重，保留第一个出现的tool）
        self.tools = []
        seen_tool_names = set()

        if self._session_handler and hasattr(self._session_handler, "tools"):
            for tool in self._session_handler.tools:
                if tool.name not in seen_tool_names:
                    self.tools.append(tool)
                    seen_tool_names.add(tool.name)

        for task_handler in self._task_handlers:
            if task_handler and hasattr(task_handler, "tools"):
                for tool in task_handler.tools:
                    if tool.name not in seen_tool_names:
                        self.tools.append(tool)
                        seen_tool_names.add(tool.name)

    @override
    async def abefore_agent(
        self, state: SessionState, runtime: Runtime
    ) -> dict[str, Any] | None:
        """
        处理用户输入、Action，分发session_runtime on_user_input、on_pause、on_resume
        """
        updated = {}
        messages = state.get("messages", [])
        context_id = state.get("context_id")
        current_scope = state.get("current_scope", "session")
        current_task_id = state.get("current_task_id", None)
        current_task_name = state.get("current_task_name", None)
        updated["current_scope"] = current_scope

        initialized = state.get("initialized", False)
        updated["initialized"] = initialized

        interrupted = state.get("interrupted", False)
        updated["interrupted"] = interrupted

        # 多语言默认
        language = state.get("language", "zh_CN")
        updated["language"] = language
        updated["language_name"] = get_language_name(language)

        # 获取用户信息
        user_profile = get_user_profile(context_id)
        updated["user_profile"] = user_profile

        # 替换用户输入
        user = UserAgentProxy(state)
        action = user.get_action()
        params = user.get_params()
        message = messages[-1] if len(messages) > 0 else None

        if message and message.type == "human":
            updated["messages"] = [
                RemoveMessage(id=message.id),
                HumanMessage(
                    content=build_human_message_content(message.content),
                    additional_kwargs={
                        **self._get_additional_kwargs(
                            HumanMessage(content=message.content),
                            message.content,
                            current_scope,
                            current_task_id,
                            current_task_name,
                        ),
                        "__name__": user_profile.get("fullname"),
                        "__avatar__": user_profile.get("img_url"),
                    },
                ),
            ]

            if current_scope == "session":
                # 处理 session handler
                new_state = await self._session_handler.aafter_user_input(
                    state, runtime, message.content, action, params
                )
                if new_state:
                    messages = updated.get(
                        "messages", []
                    ) + self._add_additional_kwargs(
                        new_state.get("messages", []),
                        current_scope,
                        current_task_id,
                        current_task_name,
                    )
                    updated.update(new_state)
                    updated["messages"] = messages
            else:
                # 处理 task handler
                current_task_name = state.get("current_task_name", None)
                if current_task_name:
                    handler = self._get_task_handler(current_task_name)
                    new_state = await handler.aafter_user_input(
                        state, runtime, message.content, action, params
                    )
                    if new_state:
                        messages = updated.get(
                            "messages", []
                        ) + self._add_additional_kwargs(
                            new_state.get("messages", []),
                            current_scope,
                            current_task_id,
                            current_task_name,
                        )
                        updated.update(new_state)
                        updated["messages"] = messages

        else:
            if current_scope == "session":
                # 处理 session handler
                new_state = None
                if action == "common-session-start":
                    new_state = (
                        await self._session_handler.abefore_session(state, runtime)
                        if not initialized
                        else await self._session_handler.aresume_session(state, runtime)
                    )
                    initialized = True
                    updated["initialized"] = initialized

                elif action == "biz-aitutor-quit-learning":
                    new_state = await self._session_handler.apause_session(
                        state, runtime
                    )

                if new_state:
                    messages = updated.get(
                        "messages", []
                    ) + self._add_additional_kwargs(
                        new_state.get("messages", []),
                        current_scope,
                        current_task_id,
                        current_task_name,
                    )
                    updated.update(new_state)
                    updated["messages"] = messages
            else:
                # 处理 task handler
                current_task_name = state.get("current_task_name", None)
                if current_task_name:
                    handler = self._get_task_handler(current_task_name)
                    new_state = None
                    if action == "common-session-start":
                        new_state = await handler.aresume(
                            state,
                            runtime,
                            current_task_id,
                            current_task_name,
                        )
                    elif action == "biz-aitutor-quit-learning":
                        new_state = await handler.apause(
                            state,
                            runtime,
                            current_task_id,
                            current_task_name,
                        )

                    if new_state:
                        messages = updated.get(
                            "messages", []
                        ) + self._add_additional_kwargs(
                            new_state.get("messages", []),
                            current_scope,
                            current_task_id,
                            current_task_name,
                        )
                        updated.update(new_state)
                        updated["messages"] = messages
        return updated

    @override
    async def aafter_agent(
        self, state: SessionState, runtime: Runtime
    ) -> dict[str, Any] | None:
        """
        TODO
        """

    @override
    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        current_scope = request.state.get("current_scope", None)
        current_task_id = request.state.get("current_task_id", None)
        current_task_name = request.state.get("current_task_name", None)

        # 组合所有信息
        parts = []
        if request.system_prompt:
            parts.append(request.system_prompt)

        # 消息压缩：根据current_scope做上下文隔离，未来需要接入SubAgent
        current_handler = (
            self._session_handler
            if current_scope == "session"
            else self._get_task_handler(current_task_name)
        )

        bind_tools = [x.name for x in current_handler.tools]
        if current_handler.skills:
            skills = get_skills_by_names(current_handler.skills)
            parts.append(build_skill_system_prompt([x.metadata for x in skills]))
            for skill in skills:
                bind_tools.extend(skill.metadata.bind_tools or [])

        system_message = SystemMessage(content="\n\n".join(parts))

        messages = [
            message
            for message in request.state.get("messages", [])
            if (
                message.additional_kwargs.get("__scope__") == "session"
                and current_scope == "session"
            )
            or (
                message.additional_kwargs.get("__scope__") == "task"
                and message.additional_kwargs.get("__task_id__") == current_task_id
                and current_scope == "task"
            )
        ]

        tools = [tool for tool in request.tools if tool.name in bind_tools]

        response = await current_handler.awrap_model_call(
            request.override(
                system_message=system_message,
                tools=tools,
                messages=messages,
                tool_choice="required",
            ),
            handler,
        )

        # 添加额外参数
        new_messages = []
        messages = response.result
        for message in messages:
            content = ""
            if message.type == "ai" and message.tool_calls:
                for tool_call in message.tool_calls:
                    if tool_call.get("name") == "_builtin_conversation":
                        content = tool_call.get("args", {}).get("text", "")

            new_messages.append(
                message.model_copy(
                    update={
                        "additional_kwargs": self._get_additional_kwargs(
                            message,
                            content,
                            current_scope,
                            current_task_id,
                            current_task_name,
                        )
                    }
                )
            )

        return ModelResponse(
            result=new_messages,
            structured_response=response.structured_response,
        )

    @override
    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[Command]],
    ) -> Command:
        updated = {}
        merged_messages = []
        current_scope = request.state.get("current_scope", None)
        current_task_id = request.state.get("current_task_id", None)
        current_task_name = request.state.get("current_task_name", None)

        tool_call = request.tool_call
        if tool_call.get("name") == "_builtin_start_task":
            id = tool_call.get("args", {}).get("id", None)
            name = tool_call.get("args", {}).get("name", None)

            # 处理 session handler
            new_state = await self._session_handler.abefore_task(
                request.state, request.runtime, id, name
            )
            if new_state:
                messages = new_state.get("messages", [])
                updated.update(new_state)
                merged_messages = merged_messages + self._add_additional_kwargs(
                    messages, current_scope, current_task_id, current_task_name
                )
                updated["messages"] = merged_messages

            # 处理工具调用
            command = cast(
                Command, await self._session_handler.awrap_tool_call(request, handler)
            )
            messages = cast(list[ToolMessage], command.update.get("messages", []))
            merged_messages = merged_messages + self._add_additional_kwargs(
                messages, current_scope, current_task_id, current_task_name
            )
            updated.update(command.update)
            updated["messages"] = merged_messages

            # 更新状态
            current_scope = "task"
            current_task_id = id
            current_task_name = name
            updated["current_scope"] = current_scope
            updated["current_task_id"] = current_task_id
            updated["current_task_name"] = current_task_name

            # 处理 task handler
            task_handler = self._get_task_handler(current_task_name)
            # 插入技能
            skills = get_skills_by_names(task_handler.skills)
            skill_context = build_skill_information_context_list(skills)
            merged_messages = merged_messages + self._add_additional_kwargs(
                [SystemMessage(content=skill_context)],
                current_scope,
                current_task_id,
                current_task_name,
            )
            updated["messages"] = merged_messages

            new_state = await task_handler.abefore(
                request.state,
                request.runtime,
                current_task_id,
                current_task_name,
            )
            if new_state:
                messages = new_state.get("messages", [])
                updated.update(new_state)
                merged_messages = merged_messages + self._add_additional_kwargs(
                    messages, current_scope, current_task_id, current_task_name
                )
                updated["messages"] = merged_messages

            # Command 是 frozen dataclass，需要创建新对象
            command = Command(update=updated)

        elif tool_call.get("name") == "_builtin_end_task":
            is_interrupt = tool_call.get("args", {}).get("is_interrupt", False)
            interrupt_reason = tool_call.get("args", {}).get("interrupt_reason", "")
            task_handler = self._get_task_handler(current_task_name)
            command = cast(
                Command, await task_handler.awrap_tool_call(request, handler)
            )

            # 处理 task handler
            new_state = await task_handler.aafter(
                request.state,
                request.runtime,
                current_task_id,
                current_task_name,
                is_interrupt,
            )
            if new_state:
                messages = new_state.get("messages", [])
                updated.update(new_state)
                merged_messages = merged_messages + self._add_additional_kwargs(
                    messages, current_scope, current_task_id, current_task_name
                )
                updated["messages"] = merged_messages

            # cache，用作插入task返回上下文
            cache_current_task_id = current_task_id
            cache_current_task_name = current_task_name

            # 处理工具调用
            messages = cast(list[ToolMessage], command.update.get("messages", []))
            merged_messages = merged_messages + self._add_additional_kwargs(
                messages, current_scope, current_task_id, current_task_name
            )
            updated["messages"] = merged_messages

            # 更新状态
            current_scope = "session"
            current_task_id = None
            current_task_name = None
            updated.update(command.update)
            updated["current_scope"] = current_scope
            updated["current_task_id"] = current_task_id
            updated["current_task_name"] = current_task_name

            # 插入task返回上下文，等同于end_task工具调用
            merged_messages = merged_messages + self._add_additional_kwargs(
                [
                    SystemMessage(
                        content=f"task[id: {cache_current_task_id}, name: {cache_current_task_name}] ended, is_interrupt: {is_interrupt}, interrupt_reason: {interrupt_reason}"
                    )
                ],
                current_scope,
                current_task_id,
                current_task_name,
            )
            updated["messages"] = merged_messages

            # 处理 session handler
            new_state = await self._session_handler.aafter_task(
                request.state,
                request.runtime,
                cache_current_task_id,
                cache_current_task_name,
                is_interrupt,
            )
            if new_state:
                messages = new_state.get("messages", [])
                updated.update(new_state)
                merged_messages = merged_messages + self._add_additional_kwargs(
                    messages,
                    current_scope,
                    current_task_id,
                    current_task_name,
                )
                updated["messages"] = merged_messages

            # Command 是 frozen dataclass，需要创建新对象
            command = Command(update=updated)

        else:
            if current_scope == "session":
                command = cast(
                    Command,
                    await self._session_handler.awrap_tool_call(request, handler),
                )
            elif current_scope == "task":
                task_handler = self._get_task_handler(current_task_name)
                command = cast(
                    Command, await task_handler.awrap_tool_call(request, handler)
                )

            if (
                tool_call.get("name") == "_builtin_conversation"
                and tool_call.get("args", {}).get("ask_question", False)
            ) or tool_call.get("name") == "_builtin_wait_system_feedback":
                updated["interrupted"] = True

            messages = cast(list[ToolMessage], command.update.get("messages", []))
            updated.update(command.update)
            merged_messages = merged_messages + self._add_additional_kwargs(
                messages,
                current_scope,
                current_task_id,
                current_task_name,
            )
            updated["messages"] = merged_messages
            command = Command(update=updated)

        return command

    # 支持中断，需要改写abefore_model、aafter_model
    @hook_config(can_jump_to=["end", "model", "tools"])
    @override
    async def abefore_model(
        self, state: State, runtime: Runtime
    ) -> dict[str, Any] | None:
        interrupted = state.get("interrupted", False)
        if interrupted:
            return {"jump_to": "end", "interrupted": False}

        # 允许直接添加工具调用，直接跳过模型
        message = state.get("messages", [])[-1]
        if message and message.type == "ai" and message.tool_calls:
            return {
                "jump_to": "tools",
            }

        return {
            "interrupted": False,
        }

    @hook_config(can_jump_to=["end", "model"])
    @override
    async def aafter_model(
        self, state: State, runtime: Runtime
    ) -> dict[str, Any] | None:
        interrupted = state.get("interrupted", False)
        if interrupted:
            return {"jump_to": "end", "interrupted": False}

        return {
            "interrupted": False,
        }

    def _get_additional_kwargs(
        self,
        message: AnyMessage,
        content: str = "",
        current_scope: Literal["session", "task"] = "session",
        current_task_id: str = "",
        current_task_name: str = "",
    ) -> dict[str, Any]:
        return {
            **build_message_additional_kwargs(
                role="user" if message.type == "human" else "assistant",
                text=content,
            ),
            **message.additional_kwargs,
            "__scope__": current_scope,
            "__task_id__": current_task_id,
            "__task_name__": current_task_name,
        }

    def _add_additional_kwargs(
        self,
        messages: list[AnyMessage],
        current_scope: Literal["session", "task"] = "session",
        current_task_id: str = "",
        current_task_name: str = "",
    ) -> list[AnyMessage]:
        # content默认“”，用户输入、Agent输出都通过_get_additional_kwargs处理了
        return [
            message.model_copy(
                update={
                    "additional_kwargs": self._get_additional_kwargs(
                        message, "", current_scope, current_task_id, current_task_name
                    )
                }
            )
            for message in messages
        ]

    def _get_task_handler(self, task_name: str) -> TaskHandler:
        for handler in self._task_handlers:
            if handler.name == task_name:
                return handler

        raise AgenticException(
            "error.middleware.session.get_task_handler_error",
            task_name,
            f"task handler not found for task name: {task_name}",
        )
